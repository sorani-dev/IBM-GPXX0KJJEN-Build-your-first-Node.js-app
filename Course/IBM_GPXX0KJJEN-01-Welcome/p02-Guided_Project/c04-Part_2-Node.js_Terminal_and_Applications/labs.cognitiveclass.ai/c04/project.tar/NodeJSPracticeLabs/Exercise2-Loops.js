//For loop, with initial value, condition, new value
//i++ increments i by 1
console.log("For Loop");
for (let i=1;i<=10;i++) {
    console.log(i)
}

console.log("While Loop");
let i=1;
while(i<=10) {
//print i and then increment it by 1    
    console.log(i++);
}


console.log("Do-While Loop");
i=0;
do {
//increment it by 1 and then print i     
    console.log(++i);
} while(i<10)
