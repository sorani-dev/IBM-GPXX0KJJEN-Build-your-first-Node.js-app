const colors = ['red', 'orange', 'yellow', 'green', 'blue', 'indigo', 'violet']

for (let color in colors) {
    console.log(colors[color])
}

